import React from 'react';
import ReactDOM from 'react-dom/client';
import QueenPortfolioPage from './QueenPortfolioPage.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <QueenPortfolioPage />
  </React.StrictMode>
);