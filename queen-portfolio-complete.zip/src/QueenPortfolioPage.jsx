import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export default function QueenPortfolioPage() {
  return (
    <div className="bg-[#F8F6FC] min-h-screen p-6 text-[#1C1C1E]">
      <header className="text-center py-12">
        <h1 className="text-4xl font-serif mb-4">Hi, I’m Queen</h1>
        <p className="text-lg max-w-2xl mx-auto">
          I help businesses grow visibility and conversions through strategic SEO and content marketing. While I’ve worked in personal branding for executives, my focus is organic growth content that scales.
        </p>
        <Button className="mt-6 bg-purple-500 text-white hover:bg-purple-600">
          Explore My Work
        </Button>
      </header>

      <section className="py-12">
        <h2 className="text-2xl font-semibold mb-6 text-center">What I Do Best</h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {["Full-Channel SEO","Content Strategy","Content Marketing","SEO & Copywriting","Social Media Content","Personal Branding (Optional)"].map((service) => (
            <Card key={service}>
              <CardContent className="p-6 text-center font-medium">
                {service}
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="py-12 bg-white">
        <h2 className="text-2xl font-semibold mb-6 text-center">Featured Projects</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          <Card>
            <CardContent className="p-6">
              <h3 className="font-bold mb-2">Influencer Brand Revamp</h3>
              <p>TikTok: 20 → 250K+ | IG: 500 → 130K+ | Revenue +2000%</p>
              <p className="text-sm mt-2">Led multi-platform content strategy and growth funnel</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <h3 className="font-bold mb-2">Executive LinkedIn Rebranding (Experience Only)</h3>
              <p>This is not a core offering, but I occasionally advise clients as an add-on.</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <h3 className="font-bold mb-2">SEO + Website Revamp</h3>
              <p>Took nonprofit site from &lt;2K to 230K+ clicks in 9 months — no ads</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <h3 className="font-bold mb-2">Email & Funnel Content</h3>
              <p>+30% open rate | Led to signups and increased site traffic</p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="py-12">
        <h2 className="text-2xl font-semibold mb-6 text-center">Skills & Tools</h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto text-center">
          {["WordPress/Kadence","Screaming Frog","Google Analytics","Canva/Figma","Meta/TikTok Tools","LinkedIn/Hootsuite"].map((tool) => (
            <Card key={tool}>
              <CardContent className="p-6 font-medium">{tool}</CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="py-12 bg-white">
        <h2 className="text-2xl font-semibold mb-6 text-center">Let’s Collaborate</h2>
        <div className="max-w-xl mx-auto text-center">
          <Input placeholder="Your email" className="mb-4" />
          <Input placeholder="How can I help?" className="mb-4" />
          <Button className="bg-purple-500 text-white hover:bg-purple-600">
            Send Message
          </Button>
        </div>
      </section>
    </div>
  );
}